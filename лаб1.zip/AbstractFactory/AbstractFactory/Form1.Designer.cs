﻿namespace AbstractFactory
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblResult = new System.Windows.Forms.Label();
            this.btnCreateProductA = new System.Windows.Forms.Button();
            this.btnCreateProductB = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Location = new System.Drawing.Point(45, 88);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(59, 13);
            this.lblResult.TabIndex = 0;
            this.lblResult.Text = "Результат";
            // 
            // btnCreateProductA
            // 
            this.btnCreateProductA.Location = new System.Drawing.Point(48, 35);
            this.btnCreateProductA.Name = "btnCreateProductA";
            this.btnCreateProductA.Size = new System.Drawing.Size(125, 23);
            this.btnCreateProductA.TabIndex = 1;
            this.btnCreateProductA.Text = "Створити Product A";
            this.btnCreateProductA.UseVisualStyleBackColor = true;
            this.btnCreateProductA.Click += new System.EventHandler(this.btnCreateProductA_Click);
            // 
            // btnCreateProductB
            // 
            this.btnCreateProductB.Location = new System.Drawing.Point(220, 34);
            this.btnCreateProductB.Name = "btnCreateProductB";
            this.btnCreateProductB.Size = new System.Drawing.Size(121, 23);
            this.btnCreateProductB.TabIndex = 2;
            this.btnCreateProductB.Text = "Створити Product B";
            this.btnCreateProductB.UseVisualStyleBackColor = true;
            this.btnCreateProductB.Click += new System.EventHandler(this.btnCreateProductB_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnCreateProductB);
            this.Controls.Add(this.btnCreateProductA);
            this.Controls.Add(this.lblResult);
            this.Name = "Form1";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblResult;
        private System.Windows.Forms.Button btnCreateProductA;
        private System.Windows.Forms.Button btnCreateProductB;
    }
}

