﻿using AbstractFactoryLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace AbstractFactory
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private void btnCreateProductA_Click(object sender, EventArgs e)
        {
            // Створюємо фабрику
            IFactory factory = new ConcreteFactory1();

            // Створюємо Product A через фабрику
            IProductA productA = factory.CreateProductA();

            // Виводимо результат
            lblResult.Text = productA.GetDetails();
        }
        private void btnCreateProductB_Click(object sender, EventArgs e)
        {
            // Створюємо фабрику
            IFactory factory = new ConcreteFactory1();

            // Створюємо Product B через фабрику
            IProductB productB = factory.CreateProductB();

            // Виводимо результат
            lblResult.Text = productB.GetDetails();
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
