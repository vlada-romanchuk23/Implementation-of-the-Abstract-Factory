﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryLibrary
{
     public class ProductA1 : IProductA
    {
        public string GetDetails()
        {
            return "Product A1";
        }
    }
}
