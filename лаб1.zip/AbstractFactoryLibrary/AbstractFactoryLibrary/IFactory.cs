﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactoryLibrary
{
    public interface IProductA
    {
        string GetDetails();
    }

    public interface IProductB
    {
        string GetDetails();
    }

    public interface IFactory
    {
        IProductA CreateProductA();
        IProductB CreateProductB();
    }
}
